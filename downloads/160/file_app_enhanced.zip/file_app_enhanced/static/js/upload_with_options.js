const fileInput = document.getElementById('fileInput');
const uploadsList = document.getElementById('uploadsList');
const folderSelect = document.getElementById('folderSelect');
const overwriteCheck = document.getElementById('overwriteCheck');
const createFolderBtn = document.getElementById('createFolderBtn');
const newFolderName = document.getElementById('newFolderName');

createFolderBtn.addEventListener('click', (e)=>{
  e.preventDefault();
  const name = newFolderName.value.trim();
  if(!name){ alert('Enter folder name'); return; }
  const parent = folderSelect.value || '';
  const fd = new FormData();
  fd.append('parent', parent);
  fd.append('name', name);
  fetch('/create_folder', {method:'POST', body: fd}).then(()=>{ location.reload(); });
});

const DEFAULT_CHUNK_SIZE = 8 * 1024 * 1024;
const CONCURRENCY = 6;

fileInput.addEventListener('change', async (e) => {
  const files = Array.from(e.target.files);
  for (const file of files) {
    startUpload(file);
  }
  e.target.value = '';
});

function createUploadElement(filename) {
  const div = document.createElement('div');
  div.className = 'upload-item card p-3 mb-2';
  div.innerHTML = `
    <div class="d-flex justify-content-between align-items-center mb-2">
      <strong>${filename}</strong>
      <span class="status">Queued</span>
    </div>
    <div class="progress progress-small mb-2"><div class="progress-bar" style="width: 0%"></div></div>
    <div class="text-muted small details"></div>
  `;
  uploadsList.prepend(div);
  return div;
}

async function startUpload(file) {
  const filename = file.name;
  const totalSize = file.size;
  const chunkSize = DEFAULT_CHUNK_SIZE;
  const totalChunks = Math.ceil(totalSize / chunkSize);

  const el = createUploadElement(filename);
  const statusEl = el.querySelector('.status');
  const bar = el.querySelector('.progress-bar');
  const details = el.querySelector('.details');
  details.textContent = `${formatBytes(totalSize)} — ${totalChunks} chunks`;

  statusEl.textContent = 'Initializing...';

  const folder = folderSelect.value || '';
  const overwrite = overwriteCheck.checked;

  const initResp = await fetch('/init_upload', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({filename, total_size: totalSize, chunk_size: chunkSize, folder, overwrite})
  });
  if (!initResp.ok) {
    const err = await initResp.json().catch(()=>({error:'unknown'}));
    statusEl.textContent = 'Init failed: ' + (err.error || initResp.status);
    return;
  }
  const { upload_id, chunk_size } = await initResp.json();
  statusEl.textContent = 'Uploading...';

  const statusRes = await fetch(`/uploaded_chunks?upload_id=${upload_id}`);
  let uploadedSet = new Set();
  if (statusRes.ok) {
    const st = await statusRes.json();
    uploadedSet = new Set(st.chunks || []);
  }

  let uploadedBytes = 0;
  for (let idx of uploadedSet) {
    uploadedBytes += Math.min(chunk_size, totalSize - idx * chunk_size);
  }
  updateProgress(bar, uploadedBytes / totalSize);

  const queue = [];
  for (let i = 0; i < totalChunks; i++) {
    if (!uploadedSet.has(i)) queue.push(i);
  }

  let active = 0;
  let done = 0;
  function next() {
    if (queue.length === 0) {
      if (active === 0) finish();
      return;
    }
    if (active >= CONCURRENCY) return;
    const chunkIndex = queue.shift();
    active++;
    uploadChunk(upload_id, chunkIndex, file, chunk_size).then((size) => {
      active--;
      done++;
      uploadedBytes += size;
      updateProgress(bar, uploadedBytes / totalSize);
      details.textContent = `${formatBytes(uploadedBytes)} / ${formatBytes(totalSize)} — ${done}/${totalChunks} chunks`;
      next();
    }).catch((err) => {
      active--;
      console.error('chunk upload error', err);
      statusEl.textContent = 'Error uploading';
      queue.unshift(chunkIndex);
      setTimeout(next, 2000);
    });
    next();
  }

  for (let i = 0; i < CONCURRENCY; i++) next();

  function finish() {
    statusEl.textContent = 'Finalizing...';
    fetch('/complete_upload', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({upload_id})
    }).then(async (res) => {
      if (!res.ok) {
        const err = await res.json();
        statusEl.textContent = 'Finalize failed: ' + (err.error || 'unknown');
        return;
      }
      const j = await res.json();
      statusEl.textContent = 'Completed';
      updateProgress(bar, 1);
    }).catch(err => {
      statusEl.textContent = 'Finalize error';
      console.error(err);
    });
  }
}

async function uploadChunk(upload_id, index, file, chunkSize) {
  const start = index * chunkSize;
  const end = Math.min(start + chunkSize, file.size);
  const slice = file.slice(start, end);
  const fd = new FormData();
  fd.append('upload_id', upload_id);
  fd.append('index', index);
  fd.append('chunk', slice, `${upload_id}.part.${index}`);
  const resp = await fetch('/upload_chunk', {method: 'POST', body: fd});
  if (!resp.ok) throw new Error('upload failed');
  return end - start;
}

function updateProgress(bar, fraction) {
  const pct = Math.floor(fraction * 100);
  bar.style.width = pct + '%';
  bar.textContent = pct + '%';
}

function formatBytes(bytes) {
  if (bytes === 0) return '0 B';
  const sizes = ['B','KB','MB','GB','TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return (bytes / Math.pow(1024, i)).toFixed(2) + ' ' + sizes[i];
}