# File Manager - Enhanced (Folders, Search, Preview, Delete/Rename, Overwrite uploads)

Features included:
- User auth (register/login). Default admin/admin123 created on first run.
- Per-user 32 GiB quota.
- Resumable chunked uploads (client splits file in 8 MiB chunks) with overwrite option and target folder support.
- Folder creation and navigation. Files are stored under `uploads/<username>/<folder>/`.
- Delete files/folders (recursive delete supported).
- Rename files/folders (server-side rename, avoids overwrite).
- Search/filter in the files view (by name substring and by type: image/video/docs).
- Image and video preview modal in the UI (streams directly with Range support).
- Range-enabled downloads for resumable/accelerated downloads.
- Frontend with Bootstrap and upload progress UI.

Run locally:
1. python -m venv venv
2. source venv/bin/activate  # or venv\\Scripts\\activate on Windows
3. pip install -r requirements.txt
4. python app.py
5. Open http://127.0.0.1:5000/ and log in (admin/admin123)

Notes:
- The built-in Flask server is for development. For production/fast uploads, run behind Nginx + Gunicorn and tune settings (worker count, sendfile/X-Accel-Redirect, client_max_body_size if using non-chunked uploads, etc.).
- Ensure server disk has enough space for user quotas.